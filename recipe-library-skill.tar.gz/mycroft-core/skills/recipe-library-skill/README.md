# <img src='https://raw.githack.com/FortAwesome/Font-Awesome/master/svgs/solid/book-open.svg' card_color='#52B54B' width='50' height='50' style='vertical-align:bottom'/> Bedtime Stories
Listen to famous bedtime stories.

## About
A skill that has a small selection of famous bedtime stories  provided by Librivox.

Stories are downloaded with the skill and can be listed by voice, selected by title, or chosen randomly.

## Examples 
* "Hey mycroft, read me a bedtime story"
* "Hey mycroft, what bedtime stories do you know"
* "Hey mycroft, read me little red riding hood"

## Credits
TREE Industries

## Category
**Entertainment**

## Supported Devices
platform_mark1 platform_picroft platform_kde platform_mark2

## Tags
#stories
#audio
#kidfriendly
